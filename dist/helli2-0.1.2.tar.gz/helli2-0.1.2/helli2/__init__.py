from helli2.turtle_helper import islamic_draw

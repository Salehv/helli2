import helli2.turtle_helper
from helli2.turtle_helper import islamic_draw, create_image
